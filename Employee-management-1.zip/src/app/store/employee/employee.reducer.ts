import { createReducer, on } from '@ngrx/store';
import { initialState } from './employee.state';
import * as EmployeeActions from './employee.actions';

export const employeeReducer = createReducer(
  initialState,

  on(EmployeeActions.loadEmployeesSuccess, (state, { employees }) => ({
    ...state,
    employees
  })),

  on(EmployeeActions.addEmployee, (state, { employee }) => ({
    ...state,
    employees: [...state.employees, employee]
  })),

  on(EmployeeActions.deleteEmployee, (state, { id }) => ({
    ...state,
    employees: state.employees.filter(emp => emp.id !== id)
  })),

  on(EmployeeActions.updateEmployee, (state, { employee }) => ({
  ...state,
  employees: state.employees.map(emp =>
    emp.id === employee.id ? employee : emp)
}))

);