import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';

import { Employee } from '../models/employee.model';
import * as EmployeeActions from '../store/employee/employee.actions';
import { selectEmployees } from '../store/employee/employee.selectors';

@Component({
  selector: 'app-employee',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './employee.html',
  styleUrls: ['./employee.css']
})
export class EmployeeComponent implements OnInit {

  
  employees$: Observable<Employee[]>;


  id: number | null = null;
  name = '';
  role = '';
  searchText = '';

  
  editMode = false;
  editId: number | null = null;

  constructor(private store: Store) {
    this.employees$ = this.store.select(selectEmployees);
  }

  ngOnInit() { 
    const data = localStorage.getItem('employees');
    const employees = data ? JSON.parse(data) : [];

    this.store.dispatch(
      EmployeeActions.loadEmployeesSuccess({ employees })
    );

    this.employees$.subscribe(empList => {
      localStorage.setItem('employees', JSON.stringify(empList));
    });
  }

  addEmployee() {
    if (!this.id || !this.name || !this.role) {
      alert('Please fill all fields');
      return;
    }

    if (this.editMode) { 
      const updatedEmployee: Employee = {
        id: this.id,
        name: this.name,
        role: this.role
      };

      this.store.dispatch(
        EmployeeActions.updateEmployee({ employee: updatedEmployee })
      );

      this.editMode = false;
      this.editId = null;

    } else { 
      const employee: Employee = {
        id: this.id,
        name: this.name,
        role: this.role
      };

      this.store.dispatch(
        EmployeeActions.addEmployee({ employee })
      );
    }

    this.clearForm();
  }

  editEmployee(emp: Employee) { 
    this.id = emp.id;
    this.name = emp.name;
    this.role = emp.role;

    this.editMode = true;
    this.editId = emp.id;
  }

  deleteEmployee(id: number) {
    this.store.dispatch(
      EmployeeActions.deleteEmployee({ id })
    );
  }

  clearForm() {
    this.id = null;
    this.name = '';
    this.role = '';
  }
}