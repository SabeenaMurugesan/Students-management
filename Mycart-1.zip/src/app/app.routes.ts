import { Routes } from '@angular/router';
import { Home } from './product/home/home';
import { Create } from './product/create/create';
import { Edit } from './product/edit/edit';
import { View } from './product/view/view';

export const routes: Routes = [
    {path:'product/home',component:Home},
    {path:'product',redirectTo:'product/home',pathMatch:'full'},
    {path:'',redirectTo:'product/home',pathMatch:'full',},
    {path:'product/create',component:Create},
    {path:'product/edit/:id',component:Edit},
    {path: 'product/view/:id',component: View}
];
