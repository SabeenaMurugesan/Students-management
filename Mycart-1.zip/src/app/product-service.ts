import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ProductInterface } from './product-interface';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class ProductService {

  constructor( private httpClient: HttpClient) {}

  getAll(){
    return this.httpClient.get<ProductInterface[]>('http://localhost:3000/products');
   
  }

  create(data: ProductInterface){
    return this.httpClient.post('http://localhost:3000/products',data);
  }

  edit(id: any) {
     return this.httpClient.get<ProductInterface>(`http://localhost:3000/products/${id}`);
  }

  update(data:ProductInterface):Observable<ProductInterface>{
    return this.httpClient.put<ProductInterface>(`http://localhost:3000/products/${data.id}`, data);
  }

  delete(id: number) {
     return this.httpClient.delete<ProductInterface>(`http://localhost:3000/products/${id}`);
  }
}
