import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { ProductInterface } from '../../product-interface';
import { ProductService } from '../../product-service';
import { ActivatedRoute } from '@angular/router';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-view',
  imports: [RouterModule,FormsModule],
  templateUrl: './view.html',
  styleUrl: './view.css',
})
export class View implements OnInit{

  product!: ProductInterface;

  constructor(private productserve:ProductService, private route:ActivatedRoute, private cd: ChangeDetectorRef){}
 
  id: string | null = null

  ngOnInit() {
  this.route.paramMap.subscribe((data) => {
      this.getProduct(data.get('id'));
  });
}   

  getProduct (id:any) {
      this.productserve.edit(id).subscribe((data)=> {
       this.product = data;
       this.cd.detectChanges();
      });
  }

}
