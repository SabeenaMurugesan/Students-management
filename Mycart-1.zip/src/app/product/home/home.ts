import { ChangeDetectorRef, Component, OnInit } from "@angular/core";
import { ActivatedRoute, RouterLink } from "@angular/router";
import { ProductInterface } from "../../product-interface";
import { ProductService } from "../../product-service";
import { FormsModule } from "@angular/forms";
import { ReactiveFormsModule } from "@angular/forms";


@Component ({
  selector:'app-home',
  imports:[FormsModule,ReactiveFormsModule,RouterLink],
  templateUrl:'./home.html',
  styleUrl:'./home.css',
})

export class Home implements OnInit{

  allproducts: ProductInterface [] = [];
  filteredProducts: ProductInterface [] = [];
  searchText: string = '';

  constructor(private productserve:ProductService, private cd:ChangeDetectorRef, private route:ActivatedRoute){}

  ngOnInit(): void {
    this.productserve.getAll().subscribe((data) => {
      this.allproducts = [...data];
      this.filteredProducts= [...data];
      this.cd.detectChanges();
    })
  }

   search () {
    const text = this.searchText.toLowerCase();
    this.filteredProducts = this.allproducts.filter((data) => {
      return data.name.toLowerCase().includes(text) ||
      data.description.toLowerCase().includes(text)
    });
  }


  deleteItem(id:any) {
    this.productserve.delete(id).subscribe(() =>{
      this.allproducts = this.allproducts.filter(product => product.id !== id)
      this.search();
      this.cd.detectChanges();
    });
  }

}