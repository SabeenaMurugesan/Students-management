import { Component,OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductInterface } from '../../product-interface';
import { ProductService } from '../../product-service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { ChangeDetectorRef } from '@angular/core';

@Component({
  selector: 'app-edit',
  standalone: true,
  imports: [ReactiveFormsModule, FormsModule, CommonModule],
  templateUrl: './edit.html',
  styleUrl: './edit.css',
})
export class Edit implements OnInit{

    constructor (private productserve : ProductService, private router: Router, private route: ActivatedRoute , private cd : ChangeDetectorRef) {}

    formdata: ProductInterface = {
      id: 0,
      name: '',
      price: 0,
      description: '',
      stock: ''
    }

    ngOnInit(): void {
      this.route.paramMap.subscribe((data) => {
          this.getByid(data.get('id'));
      })
    }

    getByid(id: any) {
      this.productserve.edit(id).subscribe((data) =>{
        this.formdata = {...data};
        this.cd.detectChanges();
      })
    }

    update() {
      this.productserve.update(this.formdata).subscribe((data) => {
        this.router.navigate(['/product/home'])
       })
    }
}

