import { Component } from '@angular/core';
import { ProductService } from '../../product-service';
import { Router } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';


@Component({
  selector: 'app-create',
  standalone: true,
  imports: [ReactiveFormsModule, FormsModule, CommonModule],
  templateUrl: './create.html',
  styleUrl: './create.css',
})
export class Create {

  constructor(private productserve: ProductService, private router: Router) {}

  formdata: any = {
    name:'',
    price: 0,
    description:'',
    stock:''
  }

create() {
  this.productserve.getAll().subscribe((data) => {

    const lastId = data.length > 0 ? data[data.length - 1].id : 0;

    const newProduct = {
      id: Number(lastId) + 1, 
      name: this.formdata.name,
      price: this.formdata.price,
      description: this.formdata.description,
      stock: this.formdata.stock
    };

    this.productserve.create(newProduct as any).subscribe(() => {
        this.router.navigate(['/product/home']);
      })
    });
  }

}



