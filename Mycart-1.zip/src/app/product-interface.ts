export interface ProductInterface {
    id:number,
    name:string,
    price:number,
    stock:string,
    description:string
}
