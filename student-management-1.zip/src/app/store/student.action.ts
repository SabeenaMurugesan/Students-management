import { createAction, props } from "@ngrx/store";
import { StudentInterface } from "../student-interface";

export const loadStudent = createAction(
    '[Student] Load Student'
);

export const loadStudentSuccess = createAction(
    '[Student] Load Success',
    props<{student: StudentInterface[]}>()
);

export const addStudent = createAction(
    '[Student] Add Student',
    props<{student: StudentInterface}>()
);

export const addStudentSuccess = createAction(
    '[Student] Add Success',
    props<{student:StudentInterface}>()
);

export const updateStudent = createAction(
    '[Student] update Student',
    props<{student: StudentInterface}>()
)

export const updateStudentSuccess = createAction(
  '[Student] Update Success',
  props<{ student: StudentInterface }>()
);

export const deleteStudent = createAction(
    '[Student] Delete Student',
    props<{id:number | string}>()
);

export const deleteStudentSuccess = createAction(
    '[Student] Delete Success',
    props<{id: number | string}>()
);

export const searchStudents = createAction(
    '[Student] search Student',
    props<{studentsearch: string}>()
);





















