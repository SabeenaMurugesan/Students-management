import { createFeatureSelector, createSelector } from "@ngrx/store";
import { StudentState } from "./student.state";

export const selectStudentState =
  createFeatureSelector<StudentState>('students');

export const selectAllStudents = createSelector(
  selectStudentState,
  (state: StudentState) => state.students
);

export const searchFilter = createSelector(
  selectAllStudents,
  (students: StudentState['students'], props: { studentsearch: string }) =>
    students.filter(student =>
      student.name.toLowerCase().includes(props.studentsearch.toLowerCase()) ||
      student.dept.toLowerCase().includes(props.studentsearch.toLowerCase()))
);