import { createReducer, on } from "@ngrx/store";
import * as StudentAction from './student.action';
import { StudentState } from "./student.state";

export const initialState: StudentState = {
    students: [],
    searching : ''
};

export const studentReducer = createReducer(
  initialState,

  on(StudentAction.loadStudentSuccess, (state, { student }) => ({
    ...state,
    students: [...student]
  })),

  on(StudentAction.addStudentSuccess, (state, { student }) => ({
    ...state,
    students: [...state.students, student]
  })),

  
  on(StudentAction.deleteStudentSuccess, (state, { id }) => ({
    ...state,
    students: state.students.filter(s => s.id !== id)
  })),

  on(StudentAction.searchStudents, (state,{studentsearch}) =>({
      ...state,
      students: state.students.filter(s => 
      s.name.toLowerCase().includes(studentsearch.toLowerCase()) ||
      s.dept.toLowerCase().includes(studentsearch.toLowerCase()) ||
      s.id.toString().toLowerCase().includes(studentsearch.toLowerCase()))
    })),

  on(StudentAction.updateStudentSuccess, (state, { student }) => ({
    ...state,
    students: state.students.filter(s => s.id === student.id ? student:s)
  }))

);