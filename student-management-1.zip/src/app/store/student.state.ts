import { StudentInterface } from "../student-interface";

export interface StudentState {
    students: StudentInterface[];
    searching:any
}
