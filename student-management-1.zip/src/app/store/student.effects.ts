import { inject, Injectable } from "@angular/core";
import { Actions, createEffect } from "@ngrx/effects";
import { StudentService } from "../student-service";
import { map, mergeMap } from "rxjs";
import * as StudentAction from './student.action';
import { ofType } from "@ngrx/effects"; 

@Injectable()
export class StudentEffect {

  private action$ = inject(Actions);
  private studentService = inject(StudentService);

  loadStudents$ = createEffect(() => this.action$.pipe(
    ofType(StudentAction.loadStudent),
    mergeMap(() =>this.studentService.getAll().pipe(
        map((students) =>StudentAction.loadStudentSuccess({ student: students }))
      ))
  ));

  addstudent$ = createEffect(() => this.action$.pipe(
    ofType(StudentAction.addStudent),
    mergeMap((action) =>this.studentService.create(action.student).pipe(
        map(() => StudentAction.loadStudent()) 
      ))
  ));

  deletestudent$ = createEffect(() => this.action$.pipe(
    ofType(StudentAction.deleteStudent),
    mergeMap((action) =>this.studentService.delete(action.id).pipe(
        map(() => StudentAction.loadStudent()) 
      ))
  ));

   updateStudent$ = createEffect(() =>this.action$.pipe(
    ofType(StudentAction.updateStudent),
    mergeMap((action) =>this.studentService.update(action.student).pipe(
      map(() => StudentAction.loadStudent())
    ))
  ))

}
 



