import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { selectAllStudents } from '../store/student.selector';
import * as StudentActions from '../store/student.action';
import { StudentInterface } from '../student-interface';
import { StudentState } from '../store/student.state';

@Component({
  selector: 'app-student',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './student.html',
  styleUrl: './student.css',
})

export class Student implements OnInit {

  allstudents$!: Observable<StudentInterface[]>;

  formdata: StudentInterface = {
    id: 0,
    name: '',
    dept: '',
  };

  searchText: string = '';

  isEditMode: boolean = false;

  constructor(private store: Store<{ students: StudentState }>) {
    this.allstudents$ = this.store.select(selectAllStudents);
  }

  ngOnInit(): void {
    this.store.dispatch(StudentActions.loadStudent());
  }

  addstd() {
    if (this.isEditMode) {
      this.store.dispatch(
        StudentActions.updateStudent({ student: this.formdata })
      );
      this.isEditMode = false;
    } else {
      this.store.dispatch(
        StudentActions.addStudent({ student: this.formdata })
      );
    }

    this.formdata = { id: 0, name: '', dept: '' };
  }

  deletestd(id: string | number) {
    this.store.dispatch(StudentActions.deleteStudent({ id }));
  }

  editstd(student: StudentInterface) {
    this.formdata = { ...student };
    this.isEditMode = true;
  }

  search(){
    this.store.dispatch(StudentActions.searchStudents({studentsearch: this.searchText }))
  }
}