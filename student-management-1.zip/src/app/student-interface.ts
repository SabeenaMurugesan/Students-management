export interface StudentInterface {
    id: string | number;
    name:string,
    dept:string
}
