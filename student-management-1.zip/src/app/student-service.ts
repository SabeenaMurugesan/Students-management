import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { StudentInterface } from './student-interface';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class StudentService {

  constructor(private httpClient:HttpClient){}

  url = 'http://localhost:3000/students';

  getAll():Observable<StudentInterface[]> {
    return this.httpClient.get<StudentInterface[]>(this.url);
    }

  create(data:StudentInterface):Observable<StudentInterface> {
    return this.httpClient.post<StudentInterface>(this.url,data);
  }

  search(id:number | string):Observable<StudentInterface> {
    return this.httpClient.get<StudentInterface>(`${this.url}/${id}`);
  }

  delete(id: number | string): Observable<any> {
    return this.httpClient.delete(`${this.url}/${id}`);
  }

  update(data: StudentInterface): Observable<StudentInterface> {
    return this.httpClient.put<StudentInterface>(`${this.url}/${data.id}`,data);
}
}
